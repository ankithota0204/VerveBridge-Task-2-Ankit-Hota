Objective: - Analyze Aviva’s Risk & Assurance Management Information (R&A MI) data to provide actionable insights and recommendations.

- Data Collection: Dataset Given 
- Data Analysis: analysing data through EDA 
- Visualization: made powerful dashboard using PowerBI
- Technologies used: python, EDA, numpy, pandas ETC
- * This experiance have given me a lot of knowlegde regarding data analysis 
